import React, { Component } from 'react';

import SearchInput from './searchInputComponent';
import List from './listComponent';

import Data from './generated.json';

class SearchComponent extends Component {

  constructor(props) {
    super(props);
    this.state = {
      list:Data
    };

  }

  searchfilter = (val) =>{
   
    let updatedList = this.state.list;

    if(val == 0) {
      this.setState({list: Data});
    } else {

      updatedList = updatedList.filter(function(item){
        return item.name.toLowerCase().search(
          val.toLowerCase()) !== -1;
      });

      if(updatedList.length != 0) {

        this.setState({list: updatedList});

      } else {
        
        let dataVal = [{
          _id:"159753",
          name:"‘Sorry No Matches found’",
          gender:"-"
        }]
        this.setState({list: dataVal});
      }
    }

  }


  render() {
    return (
      <div>
            <br />
            <SearchInput listonchange={this.searchfilter}/>
            <hr/>
            <List item={this.state.list}/>
      </div>
    );
  }
}

export default SearchComponent;
