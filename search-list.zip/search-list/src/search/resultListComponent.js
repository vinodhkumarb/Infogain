import React, { Component } from 'react';

class ResultList extends Component {

  render() {
    return (
      <tr>
          <td>{this.props.items.name}</td>
          <td>{this.props.items.gender}</td>
      </tr>
    );
  }
}

export default ResultList;
