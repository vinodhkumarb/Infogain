import React from 'react';

function InputTextSearchButton(props) {
  return (
      <div>

        <button type="button" className="btn btn-primary" onClick={props.onClickButton}>Search</button>

      </div>
    );
}

export default InputTextSearchButton;
