import React, { Component } from 'react';

import ResultList from './resultListComponent';

class List extends Component {

  render() {

    const items = this.props.item.map((item)=> {
      return (
          <ResultList items={item} key={item._id}/>
      );

    });

    return (
      <div className="container">
      <table className="table">
        <thead>
            <tr>
              <th>Name</th>
              <th>Gender</th>
            </tr>
        </thead>
        <tbody>
        {items}
        </tbody>
      </table>
     
      </div>
    );
  }
}

export default List;

