import React, { Component } from 'react';

import InputTextSearchButton from './InputTextSearchButton';

class SearchInput extends Component {
  constructor(props) {
    super(props);
    this.state = {
      inputData: ""
    };
  }

  onClickButton() {
    this.props.listonchange(this.state.inputData)
  }

  render() {
    return (
      <div className="row">
        <div className="col-xs-8 col-sm-9 col-md-10">
          <div className="form-group">
            <input 
            type="text" 
            className="form-control" 
            placeholder="Search user name" 
            onChange={(e) => { this.setState({ inputData: e.target.value })}}
            />
          </div>
        </div>
        <div className="col-xs-4 col-sm-3 col-md-2">
          <InputTextSearchButton onClickButton={()=>this.onClickButton()} />
        </div>

      </div>
    );
  }
}

export default SearchInput;
