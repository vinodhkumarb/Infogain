import React, { Component } from 'react';
import './App.css';

import SearchComponent from './search/searchComponent'

class App extends Component {
  render() {
    return (
      <div className="container">
      <br/>
        <h1 className="text-center"> User list </h1>
            <SearchComponent />
      </div>
    );
  }
}

export default App;
